<?php
return [
  'default_book_rent_days' => 7
];