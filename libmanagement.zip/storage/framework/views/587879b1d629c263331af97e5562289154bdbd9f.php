<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <table class="table table-striped">
                <tr>
                    <td colspan="2">
                        <center><?php echo QrCode::size(300)->generate(route('book.transaction',['id' => $book->id])); ?></center>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Date added</b>
                    </td>
                    <td>
                        <?php echo e($book->publication_date, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Author</b>
                    </td>
                    <td>
                        <?php echo e($book->author, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Publication date</b>
                    </td>
                    <td>
                        <?php echo e($book->publication_date, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Store Location</b>
                    </td>
                    <td>
                        <?php echo e($book->location, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>ISBN</b>
                    </td>
                    <td>
                        <?php echo e($book->isbn, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Available in stock</b>
                    </td>
                    <td>
                        <?php echo e($book->in_stock, false); ?>/<?php echo e($book->quantity, false); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Media Type</b>
                    </td>
                    <td>
                        <ul class="list-group">
                        <?php $__currentLoopData = $book->medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><?php echo e($media->title, false); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Courses</b>
                    </td>
                    <td>
                        <ul class="list-group">
                        <?php $__currentLoopData = $book->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li  class="list-group-item"><?php echo e($course->course, false); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Tags</b>
                    </td>
                    <td>
                        <?php $__currentLoopData = explode(",", $book->keywords); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($tag, false); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-9">
                            <?php echo e($book->title, false); ?>

                        </div>
                        <div class="col-md-3">
                            <?php if($book->in_stock > 0): ?>
                                <a href="<?php echo e(route('book.borrow',['id' => $book->id]), false); ?>">Borrow</a>
                            <?php endif; ?>
                            <?php if(($book->transactions()->where('type','=','borrow')->where('user_id','=', auth()->user()->id)->get()->count() - $book->transactions()->where('type','=','return')->where('user_id','=', auth()->user()->id)->get()->count()) > 0): ?>
                                    <a href="<?php echo e(route('book.return',['id' => $book->id]), false); ?>">Return</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <center><img src="<?php echo e($cover, false); ?>" alt="<?php echo e($book->title, false); ?>" class="img img-responsive img-bordered"></center>
                    <hr>
                    <p><?php echo e($book->description, false); ?></p>
                    <hr>
                    <p>
                        <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                            <?php echo e(__("Attachments"), false); ?>

                        </a>
                    </p>
                    <div class="collapse" id="collapseExample">
                        <div class="card card-body">
                            <ul class="list-group">
                                <?php $__currentLoopData = $book->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a href="<?php echo e(\Illuminate\Support\Facades\Storage::url($attachment->path), false); ?>" target="_blank"><?php echo e($attachment->path, false); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\libmanagement\resources\views/book.blade.php ENDPATH**/ ?>