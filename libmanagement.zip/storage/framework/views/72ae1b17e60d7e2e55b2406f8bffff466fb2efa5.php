<div class="btn-group" data-toggle="buttons" id="import_book_btn">
    <label class="btn btn-default btn-sm">
        Import Books
    </label>
</div>
<input type="file" id="import_book_file" name="file" style="display: none;" /><?php /**PATH D:\Projects\Laravel\libmanagement\resources\views/admin/tools/importbooks.blade.php ENDPATH**/ ?>