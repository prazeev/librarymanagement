<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard'), false); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status'), false); ?>

                        </div>
                    <?php endif; ?>
                        <p>
                            <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                Filter
                            </a>
                        </p>
                        <div class="collapse" id="collapseExample">
                            <div class="card card-body">
                                <form method="get">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="search" placeholder="Search Books, Author and ISBN" value="<?php echo e($_GET['search'] ?? '', false); ?>">
                                    </div>
                                    <button type="submit" class="btn btn-primary mb-2">Search</button>
                                </form>
                            </div>
                        </div>
                    <table class="table table-striped" width="100%">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>ISBN</th>
                            <th>Author</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($book->in_stock > 0 ? 'table-success' : 'table-danger', false); ?>">
                                <td><?php echo '<a href="'.route('book.details',['id' => $book->id]).'">'.$book->title.'</a>, '; ?></td>
                                <td><?php echo e($book->isbn, false); ?></td>
                                <td><?php echo e($book->author, false); ?></td>
                                <td><?php echo $book->in_stock > 0 ? 'Available' : 'Out of Stock'; ?></td>
                                <td>
                                    <div class="row">
                                        <?php if($book->in_stock > 0): ?>
                                        <div class="col">
                                            <a href="<?php echo e(route('book.borrow',['id' => $book->id]), false); ?>">Borrow</a>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(($book->transactions()->where('type','=','borrow')->where('user_id','=', auth()->user()->id)->get()->count() - $book->transactions()->where('type','=','return')->where('user_id','=', auth()->user()->id)->get()->count()) > 0): ?>
                                        <div class="col">
                                            <a href="<?php echo e(route('book.return',['id' => $book->id]), false); ?>">Return</a>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($books) == 0): ?>
                            <div class="alert alert-warning" role="alert">
                                No results..
                            </div>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($books->links(), false); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Laravel\libmanagement\resources\views/home.blade.php ENDPATH**/ ?>